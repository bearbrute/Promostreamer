import React from 'react';
export default function AdCard({ad, onView}){ return (
  <div className='border rounded-lg p-4'>
    <img src={ad.image||'https://via.placeholder.com/400x300'} alt={ad.title} className='w-full h-40 object-cover rounded mb-3'/>
    <h3 className='font-bold'>{ad.title}</h3>
    <p className='text-green-600'>KES {ad.price}</p>
    <button onClick={()=>onView(ad)} className='mt-2 px-3 py-1 bg-purple-600 text-white rounded'>View</button>
  </div>
); }

import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import PublicAds from './pages/PublicAds';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Subscription from './pages/Subscription';
import { FullscreenProvider } from './context/FullscreenContext';
export default function App(){
  return (
    <FullscreenProvider>
      <Router>
        <Routes>
          <Route path='/' element={<PublicAds />} />
          <Route path='/login' element={<Login />} />
          <Route path='/signup' element={<Signup />} />
          <Route path='/subscription' element={<Subscription />} />
        </Routes>
      </Router>
    </FullscreenProvider>
  );
}

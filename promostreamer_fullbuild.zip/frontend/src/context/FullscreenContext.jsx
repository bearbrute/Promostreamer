import React,{createContext,useState,useContext} from 'react';
const FullscreenContext = createContext();
export function FullscreenProvider({children}){ const [item,setItem]=useState(null); const openFullscreen=(i)=>setItem(i); const closeFullscreen=()=>setItem(null);
  return (<FullscreenContext.Provider value={{openFullscreen,closeFullscreen}}>{children}{item && (
    <div className='fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4'>
      <div className='bg-white rounded-2xl max-w-3xl w-full overflow-hidden'>
        <div className='h-96 bg-gray-200 flex items-center justify-center'><img src={item.image||'https://via.placeholder.com/800x500'} alt={item.title} className='w-full h-full object-cover'/></div>
        <div className='p-4 text-center'><h2 className='text-xl font-bold'>{item.title}</h2><p className='text-green-600 font-semibold'>KES {item.price}</p></div>
        <button onClick={closeFullscreen} className='w-full py-3 bg-purple-600 text-white'>Close</button>
      </div>
    </div>
  )}</FullscreenContext.Provider>); }
export const useFullscreen=()=>useContext(FullscreenContext);

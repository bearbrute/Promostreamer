import React,{useState} from 'react';
import axios from 'axios';
export default function Subscription(){ const [phone,setPhone]=useState(''); const [loading,setLoading]=useState(false);
  const handlePay=async()=>{ if(!phone)return alert('Enter phone'); setLoading(true); try{ const r=await axios.post('http://localhost:5000/pay',{amount:100,phone}); if(r.data.success) alert('STK Push sent'); else alert('Payment failed'); }catch(e){ alert('Error'); }finally{ setLoading(false); } };
  return (
    <div className='p-6 max-w-md mx-auto'>
      <h1 className='text-2xl font-bold mb-4'>Subscription</h1>
      <input value={phone} onChange={e=>setPhone(e.target.value)} placeholder='07XXXXXXXX' className='w-full p-2 mb-4 border rounded'/>
      <button onClick={handlePay} disabled={loading} className='w-full py-2 bg-green-600 text-white rounded'>{loading?'Processing...':'Pay KES 100 / Month'}</button>
    </div>
  );
}

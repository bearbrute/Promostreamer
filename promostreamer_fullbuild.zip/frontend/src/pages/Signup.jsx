import React,{useState} from 'react';
import axios from 'axios';
export default function Signup(){
  const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const handle = async ()=>{ try{ const r=await axios.post('http://localhost:5000/auth/signup',{name,email,password}); alert('Signed up'); }catch(e){ alert('Signup failed'); } };
  return (
    <div className='p-6 max-w-md mx-auto'>
      <h1 className='text-2xl font-bold mb-4'>Signup</h1>
      <input value={name} onChange={e=>setName(e.target.value)} placeholder='Name' className='w-full p-2 mb-2 border rounded'/>
      <input value={email} onChange={e=>setEmail(e.target.value)} placeholder='Email' className='w-full p-2 mb-2 border rounded'/>
      <input value={password} onChange={e=>setPassword(e.target.value)} placeholder='Password' type='password' className='w-full p-2 mb-4 border rounded'/>
      <button onClick={handle} className='w-full py-2 bg-purple-600 text-white rounded'>Signup</button>
    </div>
  );
}

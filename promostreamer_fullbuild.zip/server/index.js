// server/index.js
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
require('dotenv').config();
const authRoutes = require('./routes/auth');
const adsRoutes = require('./routes/ads');
const payRoutes = require('./routes/pay');
const app = express();
app.use(cors());
app.use(bodyParser.json());
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(()=>console.log('MongoDB connected')).catch(err=>console.log(err));
app.use('/auth', authRoutes);
app.use('/ads', adsRoutes);
app.use('/pay', payRoutes);
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

// server/models/Ad.js
const mongoose = require('mongoose');
const adSchema = new mongoose.Schema({
  title: String,
  price: Number,
  description: String,
  category: String,
  location: String,
  image: String,
  isSponsored: { type: Boolean, default: false },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Ad', adSchema);

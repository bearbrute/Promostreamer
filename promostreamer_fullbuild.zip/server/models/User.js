// server/models/User.js
const mongoose = require('mongoose');
const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true, sparse: true },
  phone: String,
  password: String,
  role: { type: String, enum: ['Advertiser','Creator','Clipper'], default: 'Advertiser' },
  subscriptionActive: { type: Boolean, default: false },
  subscriptionExpires: Date
});
module.exports = mongoose.model('User', userSchema);

// server/routes/ads.js
const express = require('express');
const router = express.Router();
const Ad = require('../models/Ad');
// List ads
router.get('/', async (req,res) => {
  const ads = await Ad.find().sort({ isSponsored: -1, createdAt: -1 }).limit(200);
  res.json(ads);
});
// Create ad
router.post('/', async (req,res) => {
  try {
    const ad = new Ad(req.body);
    await ad.save();
    res.json({ success:true, ad });
  } catch(err){ res.status(500).json({ error: String(err) }); }
});
module.exports = router;

// server/routes/auth.js
const express = require('express');
const router = express.Router();
const User = require('../models/User');
// Simple signup & login for demo (no hashing) - replace with bcrypt in production
router.post('/signup', async (req,res) => {
  const { name, email, phone, password, role } = req.body;
  try {
    const user = new User({ name, email, phone, password, role, subscriptionActive: false });
    await user.save();
    res.json({ success:true, user });
  } catch(err){ res.status(500).json({ error: String(err) }); }
});
router.post('/login', async (req,res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email, password });
  if(!user) return res.status(401).json({ error: 'Invalid credentials' });
  res.json({ success:true, user });
});
module.exports = router;

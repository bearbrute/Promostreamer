// server/routes/pay.js
const express = require('express');
const router = express.Router();
const axios = require('axios');
const Payment = require('../models/Payment');
// NOTE: This implementation uses placeholders and the production Daraja endpoints.
router.post('/', async (req,res) => {
  const { amount, phone, userId } = req.body;
  if(!amount || !phone) return res.status(400).json({ success:false, message:'Missing amount or phone' });
  try {
    // 1) Get access token
    const auth = Buffer.from(process.env.CONSUMER_KEY + ':' + process.env.CONSUMER_SECRET).toString('base64');
    const tokenRes = await axios.get('https://api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials', { headers: { Authorization: 'Basic ' + auth }});
    const accessToken = tokenRes.data.access_token;
    // 2) Build STK Push payload
    const timestamp = new Date().toISOString().replace(/[^0-9]/g,'').slice(0,14);
    const password = Buffer.from(process.env.SHORTCODE + process.env.PASSKEY + timestamp).toString('base64');
    const payload = {
      BusinessShortCode: process.env.SHORTCODE,
      Password: password,
      Timestamp: timestamp,
      TransactionType: 'CustomerPayBillOnline',
      Amount: amount,
      PartyA: phone,
      PartyB: process.env.SHORTCODE,
      PhoneNumber: phone,
      CallBackURL: process.env.CALLBACK_URL,
      AccountReference: 'Promostreamer',
      TransactionDesc: 'Subscription'
    };
    const stk = await axios.post('https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest', payload, { headers: { Authorization: 'Bearer ' + accessToken }});
    // store payment record
    const p = new Payment({ user: userId, amount, status: 'pending' });
    await p.save();
    res.json({ success:true, data: stk.data, paymentId: p._id });
  } catch(err) {
    console.error('MPESA error', err.message || err);
    res.status(500).json({ success:false, message: String(err.message || err) });
  }
});
// Callback endpoint (Safaricom will POST to this)
router.post('/callback', async (req,res) => {
  try {
    // Save callback payload for debugging
    const cb = req.body;
    // TODO: Parse callback and mark payment success / update subscription
    console.log('MPESA CALLBACK', JSON.stringify(cb).slice(0,200));
    res.json({ result: 'received' });
  } catch(e){ res.status(500).json({ error: String(e) }); }
});
module.exports = router;

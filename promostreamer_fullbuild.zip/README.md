PROMOSTREAMER - Ready to Deploy (Railway backend, Netlify frontend)

1) Backend (server)
   - cd server
   - npm install
   - create .env from .env.example and fill values (MONGO_URI, CONSUMER_KEY, CONSUMER_SECRET, SHORTCODE, PASSKEY, CALLBACK_URL)
   - npm start (or node index.js)

2) Frontend (Netlify)
   - cd frontend
   - npm install
   - npm run build
   - Deploy to Netlify (drag 'build' folder or connect repo)

3) Deploy backend to Railway
   - Create project on Railway, link GitHub repo, set env vars, deploy.

4) Update frontend API URLs to point to your deployed backend.
5) Point domain promostreamer.com to Netlify per Netlify docs.
